#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <fcntl.h>
#include <time.h>

int tableau[5]={0,0,0,0,0};
int* p;
int* moyenne;
int shmid,shmid2;
sem_t *sem;


int main(){

shmid = shmget(IPC_PRIVATE,sizeof(tableau),0666);
shmid2 = shmget(IPC_PRIVATE,sizeof(int),0666);
p = tableau;

sem = sem_open("/toto",O_RDWR|O_CREAT,066,0);

if(fork()){
	p = (int**) shmat(shmid,0,0);
	srand(time(NULL));
	int i;
	
	for(i=0;i<5;i++){
		tableau[i]= rand()%(1000);
	}

	for(i=0;i<5;i++){
		printf("%i\n",tableau[i]);
	}

	printf("Controle %i\n",p[2]);
	sem_post(sem);
	wait(NULL);
	moyenne = (int* )shmat(shmid2,0,0);
	printf("MOYENNE : %i\n",*moyenne);
	shmdt(p);
	shmdt(moyenne);

	shmctl(shmid,IPC_RMID,NULL);
	shmctl(shmid2,IPC_RMID,NULL);
	sem_unlink("/toto");
	sem_destroy(sem);
}
else{
	sem_wait(sem);
	printf("FEU\n");
	p = (int* )shmat(shmid,0,0);
	moyenne = (int* )shmat(shmid2,0,0);
	int i;
	for(i=0;i<5;i++){
		
		*moyenne += p[i];
	}

	*moyenne = *moyenne /5;
	
	shmdt(p);
	shmdt(moyenne);
	printf("AAAAAH JE ME MEURS\n");
	exit(0);
}
}