#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <fcntl.h>

#define CLE 12345

int main(int argc, char* argv[]){

int shmid;
char *data;
key_t cle;

cle = ftok("cle",(key_t) cle);
shmid = shmget(cle,200,IPC_CREAT|IPC_EXCL|SHM_R|SHM_W);
 if ( shmid== -1 ) {
   // perror("La creation du segment de memoire partage a echouee") ;
    shmid = shmget(cle,200,IPC_EXCL|SHM_R|SHM_W);
   // exit(1) ; // on laisse tout tomber et on sort du programme
  }

  
data = (char*)shmat(shmid,0,0);
if (data ==(char*)-1){
      perror("attachement impossible") ;
      exit(1) ;
    }
	if(argc == 2)
	{
		
		//*data = *argv[1];
		strcpy(data,argv[1]);
		printf("%s\n",data);
	}
	else
	{
		printf("%s \n",data);
	}	
/*
   if(shmdt(data)==-1){
      perror("detachement impossible") ;
      exit(1) ;
    }

     if (shmctl(shmid,IPC_RMID,NULL) == -1){
    perror("Erreur lors de la destruction") ;
    exit(1) ;
  }

  */
	return 0;

}
