/************************************************************/
/*  prg1.c : variable partag�e sans s�maphore               */
/*                                                          */
/*  Un processus et son fils partagent une variable enti�re */
/*  en m�moire partag�e. La variable, initialis�e � 0, est  */
/*  incr�ment�e 1000000 fois par chacun des deux processus. */
/*  La valeur finale de cette variable est affich�e par le  */
/*  processus p�re. Celui-ci s'est assur� que son fils      */
/*  �tait termin� (wait). Pourtant la  valeur affich�e est  */
/*  souvent diff�rente de 2000000 !                         */
/************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <fcntl.h>

pid_t pid;
int shmid, i;
int *p;

void erreurSystemeFin(const char* msg,int valeur_retour)
  {
  perror(msg);
  exit(valeur_retour);
  }

main()
{
  shmid = shmget(IPC_PRIVATE, sizeof(int), 0666);
  p = (int *)shmat(shmid, NULL, 0);
  *p = 0;	//initialisation � 0 du compteur
  sem_t *semaphore;
  semaphore =sem_open("/toto2",O_RDWR|O_CREAT,066,1);

  switch (pid=fork()) {
     case (pid_t) -1 : erreurSystemeFin("",1);
     case (pid_t)  0 :   //processus fils
	

  for (i = 0; i < 1000000; i++) {
    sem_wait(semaphore);
		    (*p)++;		
    sem_post(semaphore);
		//printf("Valeur dans le fils : %d\n", *p);
	}		

        exit(0);
     default:		//processus pere
	
   
  for (i = 0; i < 1000000; i++) {
sem_wait(semaphore);
  	(*p)++;
 sem_post(semaphore);
		//printf("Valeur dans le pere : %d\n", *p);
	}
     
     }
     
  wait(NULL);
  printf("Valeur finale de l'entier : %d\n", *p);
  shmctl(shmid, IPC_RMID, NULL);
  sem_unlink("/toto2");
  sem_destroy(semaphore);
  exit(0);

}

